/**
 * COMPONENTES REACT - Pyter v2 Advanced
 * 
 * Visualização de Rizoma e Dashboard Afetivo
 */

import React, { useEffect, useRef, useState } from "react";
import type { MemoryNode, MemoryConnection, RizomMetrics } from "../../../drizzle/schema";

// ============================================
// 1. MEMORY RIZOMA VISUALIZATION
// ============================================

interface RizomGraphProps {
  nodes: MemoryNode[];
  connections: MemoryConnection[];
  onNodeClick?: (node: MemoryNode) => void;
}

/**
 * Visualização interativa da rede de memória (Rizoma)
 * Usa canvas para performance
 */
export function MemoryRizoma({ nodes, connections, onNodeClick }: RizomGraphProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [selectedNode, setSelectedNode] = useState<MemoryNode | null>(null);
  const [hoveredNode, setHoveredNode] = useState<MemoryNode | null>(null);

  // Simular layout de força (força-dirigido)
  const [positions, setPositions] = useState<Map<number, { x: number; y: number }>>(() => {
    const map = new Map();
    nodes.forEach((node, i) => {
      const angle = (i / nodes.length) * Math.PI * 2;
      const radius = 150;
      map.set(node.id, {
        x: 300 + Math.cos(angle) * radius,
        y: 300 + Math.sin(angle) * radius,
      });
    });
    return map;
  });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Limpar canvas
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Desenhar conexões
    connections.forEach((conn) => {
      const source = positions.get(Number(conn.sourceNodeId));
      const target = positions.get(Number(conn.targetNodeId));

      if (source && target) {
        const resonance = Number(conn.resonanceScore || 0);
        ctx.strokeStyle = `rgba(124, 58, 237, ${resonance})`;
        ctx.lineWidth = 2 * resonance;
        ctx.beginPath();
        ctx.moveTo(source.x, source.y);
        ctx.lineTo(target.x, target.y);
        ctx.stroke();
      }
    });

    // Desenhar nodos
    nodes.forEach((node) => {
      const pos = positions.get(node.id as any);
      if (!pos) return;

      // Cor baseada em valência
      const valence = parseFloat(node.valence as any);
      const hue = ((valence + 1) / 2) * 240; // 0-240 (azul a vermelho)
      const color = `hsl(${hue}, 70%, 50%)`;

      // Tamanho baseado em importância (número de conexões)
      const connectionCount = connections.filter(
        (c) => c.sourceNodeId === node.id || c.targetNodeId === node.id
      ).length;
      const radius = 10 + connectionCount * 2;

      // Desenhar círculo
      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.arc(pos.x, pos.y, radius, 0, Math.PI * 2);
      ctx.fill();

      // Destaque se selecionado
      if (selectedNode?.id === node.id) {
        ctx.strokeStyle = "#000000";
        ctx.lineWidth = 3;
        ctx.stroke();
      }

      // Destaque se hover
      if (hoveredNode?.id === node.id) {
        ctx.strokeStyle = "#7c3aed";
        ctx.lineWidth = 2;
        ctx.stroke();
      }
    });
  }, [nodes, connections, positions, selectedNode, hoveredNode]);

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    // Encontrar nodo clicado
    for (const node of nodes) {
      const pos = positions.get(node.id as any);
      if (!pos) continue;

      const dist = Math.sqrt(Math.pow(x - pos.x, 2) + Math.pow(y - pos.y, 2));
      if (dist < 20) {
        setSelectedNode(node);
        onNodeClick?.(node);
        return;
      }
    }

    setSelectedNode(null);
  };

  return (
    <div className="rizoma-container">
      <canvas
        ref={canvasRef}
        width={600}
        height={600}
        onClick={handleCanvasClick}
        onMouseMove={(e) => {
          const canvas = canvasRef.current;
          if (!canvas) return;

          const rect = canvas.getBoundingClientRect();
          const x = e.clientX - rect.left;
          const y = e.clientY - rect.top;

          for (const node of nodes) {
            const pos = positions.get(node.id as any);
            if (!pos) continue;

            const dist = Math.sqrt(Math.pow(x - pos.x, 2) + Math.pow(y - pos.y, 2));
            if (dist < 20) {
              setHoveredNode(node);
              return;
            }
          }

          setHoveredNode(null);
        }}
        className="border-2 border-purple-300 rounded-lg cursor-pointer"
      />

      {selectedNode && (
        <div className="mt-4 p-4 bg-purple-50 rounded-lg">
          <h3 className="font-bold text-lg">{selectedNode.nodeName}</h3>
          <p className="text-sm text-gray-600">{selectedNode.content}</p>
          <div className="mt-2 flex gap-4 text-xs">
            <span>Valência: {parseFloat(selectedNode.valence as any).toFixed(2)}</span>
            <span>Arousal: {parseFloat(selectedNode.arousal as any).toFixed(2)}</span>
            <span>Estado: {selectedNode.cognitiveState}</span>
          </div>
        </div>
      )}
    </div>
  );
}

// ============================================
// 2. AFFECTIVE DASHBOARD
// ============================================

interface AffectiveDashboardProps {
  metadata: {
    valence: number;
    arousal: number;
    primaryEmotion: string;
    userAiSynchronization: number;
    resonanceFieldStrength: number;
    consciousState?: string;
    subconsciousState?: string;
    metaState?: string;
  };
}

/**
 * Dashboard de análise emocional em tempo real
 */
export function AffectiveDashboard({ metadata }: AffectiveDashboardProps) {
  return (
    <div className="affective-dashboard grid grid-cols-2 gap-4 p-4">
      {/* Trajetória Emocional */}
      <div className="bg-gradient-to-br from-blue-50 to-purple-50 p-4 rounded-lg">
        <h3 className="font-bold mb-2">Estado Emocional</h3>
        <div className="space-y-2">
          <div>
            <label className="text-sm text-gray-600">Valência</label>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-gradient-to-r from-red-500 to-green-500 h-2 rounded-full transition-all"
                style={{ width: `${((metadata.valence + 1) / 2) * 100}%` }}
              />
            </div>
            <span className="text-xs">{metadata.valence.toFixed(2)}</span>
          </div>

          <div>
            <label className="text-sm text-gray-600">Arousal</label>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-gradient-to-r from-blue-500 to-orange-500 h-2 rounded-full transition-all"
                style={{ width: `${metadata.arousal * 100}%` }}
              />
            </div>
            <span className="text-xs">{metadata.arousal.toFixed(2)}</span>
          </div>

          <div className="mt-3 p-2 bg-white rounded border-l-4 border-purple-500">
            <span className="text-sm font-semibold">{metadata.primaryEmotion}</span>
          </div>
        </div>
      </div>

      {/* Sincronização Usuário-IA */}
      <div className="bg-gradient-to-br from-green-50 to-emerald-50 p-4 rounded-lg">
        <h3 className="font-bold mb-2">Sincronização</h3>
        <div className="space-y-3">
          <div>
            <label className="text-sm text-gray-600">Usuário-IA</label>
            <div className="relative w-full h-8 bg-gray-200 rounded-full overflow-hidden">
              <div
                className="absolute h-full bg-gradient-to-r from-emerald-400 to-green-500 transition-all"
                style={{ width: `${metadata.userAiSynchronization * 100}%` }}
              />
              <span className="absolute inset-0 flex items-center justify-center text-xs font-bold">
                {(metadata.userAiSynchronization * 100).toFixed(0)}%
              </span>
            </div>
          </div>

          <div>
            <label className="text-sm text-gray-600">Campo de Ressonância</label>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-gradient-to-r from-violet-500 to-fuchsia-500 h-2 rounded-full transition-all"
                style={{ width: `${metadata.resonanceFieldStrength * 100}%` }}
              />
            </div>
            <span className="text-xs">{metadata.resonanceFieldStrength.toFixed(2)}</span>
          </div>
        </div>
      </div>

      {/* Estados Cognitivos */}
      <div className="col-span-2 bg-gradient-to-br from-indigo-50 to-blue-50 p-4 rounded-lg">
        <h3 className="font-bold mb-2">Camadas Cognitivas</h3>
        <div className="grid grid-cols-3 gap-2 text-sm">
          <div className="p-2 bg-white rounded border-l-4 border-blue-500">
            <span className="text-xs text-gray-600">Consciente</span>
            <p className="font-semibold text-sm">{metadata.consciousState || "—"}</p>
          </div>
          <div className="p-2 bg-white rounded border-l-4 border-purple-500">
            <span className="text-xs text-gray-600">Subconsciente</span>
            <p className="font-semibold text-sm">{metadata.subconsciousState || "—"}</p>
          </div>
          <div className="p-2 bg-white rounded border-l-4 border-pink-500">
            <span className="text-xs text-gray-600">Meta</span>
            <p className="font-semibold text-sm">{metadata.metaState || "—"}</p>
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================
// 3. RIZOM METRICS DISPLAY
// ============================================

interface RizomMetricsDisplayProps {
  metrics: {
    totalNodes: number;
    totalConnections: number;
    averageResonance: number;
    networkCoherence: number;
    networkDensity: number;
  };
}

/**
 * Exibe métricas da rede de memória
 */
export function RizomMetricsDisplay({ metrics }: RizomMetricsDisplayProps) {
  return (
    <div className="grid grid-cols-5 gap-2 p-4 bg-gray-50 rounded-lg">
      <div className="text-center">
        <div className="text-2xl font-bold text-purple-600">{metrics.totalNodes}</div>
        <div className="text-xs text-gray-600">Nodos</div>
      </div>

      <div className="text-center">
        <div className="text-2xl font-bold text-blue-600">{metrics.totalConnections}</div>
        <div className="text-xs text-gray-600">Conexões</div>
      </div>

      <div className="text-center">
        <div className="text-2xl font-bold text-green-600">
          {(metrics.averageResonance * 100).toFixed(0)}%
        </div>
        <div className="text-xs text-gray-600">Ressonância</div>
      </div>

      <div className="text-center">
        <div className="text-2xl font-bold text-orange-600">
          {(metrics.networkDensity * 100).toFixed(0)}%
        </div>
        <div className="text-xs text-gray-600">Densidade</div>
      </div>

      <div className="text-center">
        <div className="text-2xl font-bold text-pink-600">
          {(metrics.networkCoherence * 100).toFixed(0)}%
        </div>
        <div className="text-xs text-gray-600">Coerência</div>
      </div>
    </div>
  );
}

// ============================================
// 4. CHAT COM CONTEXTO DE MEMÓRIA
// ============================================

interface ChatWithMemoryProps {
  conversationId: number;
  onSendMessage: (message: string) => Promise<void>;
  relevantMemories?: MemoryNode[];
}

/**
 * Chat que mostra memórias relevantes
 */
export function ChatWithMemory({
  conversationId,
  onSendMessage,
  relevantMemories = [],
}: ChatWithMemoryProps) {
  const [message, setMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleSend = async () => {
    if (!message.trim()) return;

    setIsLoading(true);
    try {
      await onSendMessage(message);
      setMessage("");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="chat-with-memory space-y-4">
      {/* Memórias Relevantes */}
      {relevantMemories.length > 0 && (
        <div className="bg-purple-50 p-3 rounded-lg border-l-4 border-purple-500">
          <h4 className="text-sm font-semibold text-purple-900 mb-2">
            Memórias Relevantes
          </h4>
          <div className="space-y-1">
            {relevantMemories.slice(0, 3).map((mem) => (
              <div key={mem.id} className="text-xs text-purple-800 p-1 bg-white rounded">
                <strong>{mem.nodeName}:</strong> {mem.content.substring(0, 50)}...
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Input */}
      <div className="flex gap-2">
        <input
          type="text"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          onKeyPress={(e) => e.key === "Enter" && handleSend()}
          placeholder="Digite sua mensagem..."
          className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
          disabled={isLoading}
        />
        <button
          onClick={handleSend}
          disabled={isLoading || !message.trim()}
          className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50"
        >
          {isLoading ? "..." : "Enviar"}
        </button>
      </div>
    </div>
  );
}
