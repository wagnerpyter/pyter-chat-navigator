import { useState, useEffect, useRef } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Loader2, Send, Brain, BarChart3 } from "lucide-react";
import { Streamdown } from "streamdown";
import { Link } from "wouter";

interface Message {
  id: number;
  role: "user" | "assistant";
  content: string;
  createdAt: Date;
}

export default function Chat() {
  const { user, isAuthenticated } = useAuth();
  const [conversationId, setConversationId] = useState<number | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [profile, setProfile] = useState<any>(null);

  const createConvMutation = trpc.chat.createConversation.useMutation();
  const sendMessageMutation = trpc.chat.sendMessage.useMutation();
  const getMessagesQuery = trpc.chat.getMessages.useQuery(
    { conversationId: conversationId! },
    { enabled: !!conversationId }
  );
  const getProfileQuery = trpc.profile.getProfile.useQuery();

  // Initialize conversation
  useEffect(() => {
    if (isAuthenticated && !conversationId) {
      createConvMutation.mutate(
        { title: "Conversa Pyter" },
        {
          onSuccess: (conv) => {
            setConversationId(conv.id);
          },
        }
      );
    }
  }, [isAuthenticated]);

  // Update messages when conversation changes
  useEffect(() => {
    if (getMessagesQuery.data) {
      setMessages(getMessagesQuery.data as Message[]);
    }
  }, [getMessagesQuery.data]);

  // Update profile
  useEffect(() => {
    if (getProfileQuery.data) {
      setProfile(getProfileQuery.data);
    }
  }, [getProfileQuery.data]);

  // Scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = async () => {
    if (!input.trim() || !conversationId || isLoading) return;

    const userMessage = input;
    setInput("");
    setIsLoading(true);

    try {
      sendMessageMutation.mutate(
        { conversationId, content: userMessage },
        {
          onSuccess: (result) => {
            setMessages((prev) => [
              ...prev,
              {
                id: result.userMessage.id,
                role: "user",
                content: result.userMessage.content,
                createdAt: result.userMessage.createdAt,
              },
              {
                id: result.assistantMessage.id,
                role: "assistant",
                content: result.assistantMessage.content,
                createdAt: result.assistantMessage.createdAt,
              },
            ]);
            setProfile(result.profileAnalysis);
            getProfileQuery.refetch();
          },
          onError: () => {
            setInput(userMessage);
          },
          onSettled: () => {
            setIsLoading(false);
          },
        }
      );
    } catch (error) {
      setIsLoading(false);
    }
  };

  // Chat é público, sem necessidade de autenticação
  // if (!isAuthenticated) { ... }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="border-b border-border/50 bg-card sticky top-0 z-40">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-3">
            <Brain className="w-6 h-6 text-blue-600" />
            <div>
              <h1 className="font-bold text-lg">Pyter Chat Navigator</h1>
              <p className="text-xs text-muted-foreground">Análise em tempo real</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            {profile && (
              <div className="text-right">
                <p className="text-sm font-medium">{profile.profileType}</p>
                <p className="text-xs text-muted-foreground">ECIA: {profile.eciaScore}</p>
              </div>
            )}
            <Link href="/dashboard">
              <Button variant="outline" size="sm">
                <BarChart3 className="w-4 h-4 mr-2" />
                Dashboard
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Main Chat Area */}
      <div className="flex-1 container py-6 flex flex-col overflow-hidden">
        {/* Messages */}
        <div className="flex-1 overflow-y-auto mb-6 space-y-4">
          {messages.length === 0 ? (
            <div className="h-full flex items-center justify-center">
              <Card className="rounded-xl border border-border shadow-sm p-6 text-center max-w-md">
                <Brain className="w-12 h-12 text-blue-600 mx-auto mb-4" />
                <h2 className="text-xl font-bold mb-2">Bem-vindo ao Pyter</h2>
                <p className="text-muted-foreground mb-4">
                  Comece uma conversa para que a IA analise seu perfil cognitivo em tempo real.
                </p>
                <p className="text-xs text-muted-foreground">
                  Suas respostas serão analisadas para determinar seu ECIA Estimado e padrões de interação.
                </p>
              </Card>
            </div>
          ) : (
            messages.map((msg, idx) => (
              <div
                key={idx}
                className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"} animate-slideInRight`}
              >
                <div
                  className={`max-w-md lg:max-w-2xl px-4 py-3 rounded-lg ${
                    msg.role === "user"
                      ? "bg-blue-600 text-white rounded-br-none"
                      : "bg-card border border-border rounded-bl-none"
                  }`}
                >
                  {msg.role === "assistant" ? (
                    <Streamdown>{msg.content}</Streamdown>
                  ) : (
                    <p className="text-sm">{msg.content}</p>
                  )}
                </div>
              </div>
            ))
          )}
          {isLoading && (
            <div className="flex justify-start">
              <div className="bg-card border border-border px-4 py-3 rounded-lg rounded-bl-none flex items-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin" />
                <span className="text-sm text-muted-foreground">Digitando...</span>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Profile Info */}
        {profile && profile.profileType !== "Não Determinado" && (
          <Card className="rounded-xl border border-border shadow-sm p-6 bg-gradient-to-r from-blue-600/10 to-purple-600/10 border-blue-500/20 mb-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <div>
                <p className="text-xs text-muted-foreground">Perfil</p>
                <p className="font-semibold">{profile.profileType}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">ECIA</p>
                <p className="font-semibold">{profile.eciaScore}/100</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Literalidade</p>
                <p className="font-semibold">{profile.literality}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Contextualização</p>
                <p className="font-semibold">{profile.contextualization}</p>
              </div>
            </div>
          </Card>
        )}

        {/* Input */}
        <div className="flex gap-2">
          <Input
            placeholder="Digite sua mensagem..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
            disabled={isLoading}
            className="flex-1"
          />
          <Button
            onClick={handleSendMessage}
            disabled={isLoading || !input.trim()}
            className="bg-blue-600 text-white hover:bg-blue-700 px-6 py-3 rounded-lg font-medium transition-all"
          >
            {isLoading ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Send className="w-4 h-4" />
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}
