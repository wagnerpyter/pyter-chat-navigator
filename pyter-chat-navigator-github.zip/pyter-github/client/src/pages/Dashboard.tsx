import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { Brain, BarChart3, TrendingUp, Zap } from "lucide-react";
import { Link } from "wouter";

export default function Dashboard() {
  const { user, isAuthenticated } = useAuth();
  const profileQuery = trpc.profile.getProfile.useQuery();
  const metricsQuery = trpc.profile.getMetrics.useQuery();
  const studyDataQuery = trpc.study.getStudyData.useQuery({});

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="rounded-xl border border-border shadow-sm p-6 text-center">
          <h2 className="text-2xl font-bold mb-4">Acesso Necessário</h2>
          <p className="text-muted-foreground mb-6">Por favor, faça login para acessar o dashboard.</p>
          <Link href="/">
            <Button className="bg-blue-600 text-white hover:bg-blue-700 px-6 py-3 rounded-lg font-medium transition-all">Voltar para Home</Button>
          </Link>
        </Card>
      </div>
    );
  }

  const profile = profileQuery.data;
  const metrics = metricsQuery.data;
  const studyData = studyDataQuery.data || [];

  // Extract IA comparison data
  const iaComparisonData = studyData
    .find((d: any) => d.category === "IA_Comparison")
    ?.data.map((ia: any) => ({
      name: ia.name.replace("Resposta ", "R").replace(" (Manus)", ""),
      ecia: ia.eciaScore,
    })) || [];

  // Extract autonomy protocol data
  const autonomyData = studyData
    .find((d: any) => d.category === "Autonomy_Protocol")
    ?.data.map((level: any) => ({
      level: level.level,
      title: level.title,
      description: level.objective,
    })) || [];

  // Profile metrics for radar-like visualization
  const profileMetrics = profile ? [
    { name: "Literalidade", value: getLiteralityScore(profile.literality) },
    { name: "Contextualização", value: getContextualizationScore(profile.contextualization) },
    { name: "Modularidade", value: getModularityScore(profile.modularity) },
  ] : [];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 bg-card sticky top-0 z-40">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-3">
            <BarChart3 className="w-6 h-6 text-blue-600" />
            <h1 className="font-bold text-lg">Dashboard Pyter</h1>
          </div>
          <Link href="/chat">
            <Button className="bg-blue-600 text-white hover:bg-blue-700 px-6 py-3 rounded-lg font-medium transition-all">Voltar ao Chat</Button>
          </Link>
        </div>
      </header>

      {/* Main Content */}
      <div className="container py-8">
        {/* Profile Section */}
        {profile && (
          <section className="mb-8">
            <h2 className="text-2xl font-bold mb-4">Seu Perfil Cognitivo</h2>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card className="rounded-xl border border-border shadow-sm p-6 bg-gradient-to-br from-blue-600/10 to-blue-600/5 border-blue-500/20">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-xs text-muted-foreground">Perfil</p>
                  <Brain className="w-4 h-4 text-blue-600" />
                </div>
                <p className="text-2xl font-bold">{profile.profileType}</p>
              </Card>
              <Card className="rounded-xl border border-border shadow-sm p-6 bg-gradient-to-br from-purple-600/10 to-purple-600/5 border-purple-500/20">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-xs text-muted-foreground">ECIA Estimado</p>
                  <TrendingUp className="w-4 h-4 text-purple-600" />
                </div>
                <p className="text-2xl font-bold">{profile.eciaScore}/100</p>
              </Card>
              <Card className="rounded-xl border border-border shadow-sm p-6 bg-gradient-to-br from-indigo-600/10 to-indigo-600/5 border-indigo-500/20">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-xs text-muted-foreground">Literalidade</p>
                  <Zap className="w-4 h-4 text-indigo-600" />
                </div>
                <p className="text-lg font-bold">{profile.literality}</p>
              </Card>
              <Card className="rounded-xl border border-border shadow-sm p-6 bg-gradient-to-br from-cyan-600/10 to-cyan-600/5 border-cyan-500/20">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-xs text-muted-foreground">Contextualização</p>
                  <Brain className="w-4 h-4 text-cyan-600" />
                </div>
                <p className="text-lg font-bold">{profile.contextualization}</p>
              </Card>
            </div>
          </section>
        )}

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* IA Comparison Chart */}
          {iaComparisonData.length > 0 && (
            <Card className="rounded-xl border border-border shadow-sm p-6">
              <h3 className="text-lg font-bold mb-4">Comparação de IAs (ECIA)</h3>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={iaComparisonData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="name" stroke="var(--muted-foreground)" />
                  <YAxis stroke="var(--muted-foreground)" />
                  <Tooltip contentStyle={{ backgroundColor: "var(--card)", border: "1px solid var(--border)" }} />
                  <Bar dataKey="ecia" fill="#3b82f6" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </Card>
          )}

          {/* Profile Metrics Chart */}
          {profileMetrics.length > 0 && (
            <Card className="rounded-xl border border-border shadow-sm p-6">
              <h3 className="text-lg font-bold mb-4">Suas Métricas de Interação</h3>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={profileMetrics}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="name" stroke="var(--muted-foreground)" />
                  <YAxis stroke="var(--muted-foreground)" domain={[0, 100]} />
                  <Tooltip contentStyle={{ backgroundColor: "var(--card)", border: "1px solid var(--border)" }} />
                  <Bar dataKey="value" fill="#8b5cf6" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </Card>
          )}
        </div>

        {/* Autonomy Protocol Section */}
        {autonomyData.length > 0 && (
          <section className="mb-8">
            <h2 className="text-2xl font-bold mb-4">Protocolo de Autonomia</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {autonomyData.map((level: any, idx: number) => (
                <Card key={idx} className="rounded-xl border border-border shadow-sm p-6 hover:border-blue-500/50">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-xs font-semibold text-blue-600">Nível {level.level}</p>
                    <div className="w-8 h-8 rounded-full bg-blue-600/10 flex items-center justify-center text-xs font-bold text-blue-600">
                      {level.level}
                    </div>
                  </div>
                  <h4 className="font-bold mb-2">{level.title}</h4>
                  <p className="text-xs text-muted-foreground">{level.description}</p>
                </Card>
              ))}
            </div>
          </section>
        )}

        {/* Study Data Section */}
        <section>
          <h2 className="text-2xl font-bold mb-4">Base de Conhecimento Pyter</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {studyData.map((data: any, idx: number) => (
              <Card key={idx} className="rounded-xl border border-border shadow-sm p-6">
                <h3 className="font-bold mb-3">{data.name}</h3>
                <div className="text-sm text-muted-foreground space-y-2">
                  {Array.isArray(data.data) && data.data.length > 0 && (
                    <ul className="list-disc list-inside space-y-1">
                      {data.data.slice(0, 3).map((item: any, i: number) => (
                        <li key={i}>
                          {item.name || item.title || item.fear || JSON.stringify(item).substring(0, 50)}
                        </li>
                      ))}
                      {data.data.length > 3 && <li>... e mais {data.data.length - 3} itens</li>}
                    </ul>
                  )}
                </div>
              </Card>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}

function getLiteralityScore(level: string): number {
  const scores: Record<string, number> = {
    "Baixa": 20,
    "Média-Baixa": 40,
    "Média": 60,
    "Média-Alta": 80,
    "Alta": 100,
  };
  return scores[level] || 50;
}

function getContextualizationScore(level: string): number {
  const scores: Record<string, number> = {
    "Baixa": 25,
    "Média": 50,
    "Alta": 75,
    "Muito Alta": 100,
  };
  return scores[level] || 50;
}

function getModularityScore(level: string): number {
  const scores: Record<string, number> = {
    "Baixa": 25,
    "Média": 50,
    "Alta": 75,
    "Muito Alta": 100,
  };
  return scores[level] || 50;
}
