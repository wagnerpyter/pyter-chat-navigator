import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowRight, Brain, BarChart3, MessageCircle, Zap } from "lucide-react";
import { getLoginUrl } from "@/const";
import { Link } from "wouter";

export default function Home() {
  const { user, isAuthenticated } = useAuth();

  if (isAuthenticated) {
    return (
      <div className="min-h-screen bg-background">
        {/* Navigation */}
        <nav className="border-b border-border/50 sticky top-0 z-50 bg-background/95 backdrop-blur">
          <div className="container flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <Brain className="w-6 h-6 text-blue-600" />
              <span className="text-xl font-bold gradient-text">Pyter</span>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-sm text-muted-foreground">Bem-vindo, {user?.name}</span>
              <Link href="/chat">
                <Button className="bg-blue-600 text-white hover:bg-blue-700 px-6 py-3 rounded-lg font-medium transition-all">Ir para Chat</Button>
              </Link>
            </div>
          </div>
        </nav>

        {/* Hero Section */}
        <section className="container py-20 md:py-32">
          <div className="max-w-3xl mx-auto text-center animate-fadeInUp">
            <h1 className="text-5xl md:text-6xl font-bold mb-6">
              Explore Seus <span className="gradient-text">Padrões Cognitivos</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
              Uma plataforma elegante para entender como você interage com Inteligência Artificial
              e descobrir seu perfil cognitivo único baseado no estudo Pyter.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/chat">
                <Button size="lg" className="bg-blue-600 text-white hover:bg-blue-700 px-6 py-3 rounded-lg font-medium transition-all w-full sm:w-auto">
                  Começar Conversa
                  <ArrowRight className="ml-2 w-4 h-4" />
                </Button>
              </Link>
              <Link href="/dashboard">
                <Button size="lg" variant="outline" className="w-full sm:w-auto">
                  Ver Dashboard
                </Button>
              </Link>
            </div>
          </div>
        </section>

        {/* Features Grid */}
        <section className="container py-20">
          <h2 className="text-3xl font-bold text-center mb-12">Funcionalidades Principais</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                icon: MessageCircle,
                title: "Chat Inteligente",
                description: "Converse com uma IA que se adapta ao seu perfil cognitivo e ajusta seu tom de voz.",
              },
              {
                icon: Brain,
                title: "Classificação de Perfil",
                description: "Descubra se você é IA-Nativo, IA-Compatível ou Neurotípico através de análise em tempo real.",
              },
              {
                icon: BarChart3,
                title: "Métricas Detalhadas",
                description: "Visualize seu ECIA Estimado e análise de literalidade, contextualização e modularidade.",
              },
              {
                icon: Zap,
                title: "Protocolo de Autonomia",
                description: "Explore os 4 níveis de autonomia e como a IA se relaciona com você em cada estágio.",
              },
              {
                icon: Brain,
                title: "Base de Conhecimento",
                description: "Acesse dados completos do estudo Pyter sobre perfis cognitivos e interação com IA.",
              },
              {
                icon: BarChart3,
                title: "Dashboard Analítico",
                description: "Visualize gráficos comparativos de IAs, perfis e padrões de comportamento.",
              },
            ].map((feature, idx) => (
              <Card key={idx} className="rounded-xl border border-border shadow-sm p-6 group hover:border-blue-500/50">
                <feature.icon className="w-8 h-8 text-blue-600 mb-4 group-hover:scale-110 smooth-transition" />
                <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                <p className="text-muted-foreground text-sm">{feature.description}</p>
              </Card>
            ))}
          </div>
        </section>

        {/* CTA Section */}
        <section className="container py-20">
          <Card className="rounded-xl border border-border shadow-sm p-6 bg-gradient-to-r from-blue-600/10 to-purple-600/10 border-blue-500/20">
            <div className="text-center">
              <h2 className="text-3xl font-bold mb-4">Pronto para começar?</h2>
              <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
                Inicie uma conversa e deixe a IA analisar seus padrões cognitivos em tempo real.
              </p>
              <Link href="/chat">
                <Button size="lg" className="bg-blue-600 text-white hover:bg-blue-700 px-6 py-3 rounded-lg font-medium transition-all">
                  Começar Agora
                  <ArrowRight className="ml-2 w-4 h-4" />
                </Button>
              </Link>
            </div>
          </Card>
        </section>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="border-b border-border/50 sticky top-0 z-50 bg-background/95 backdrop-blur">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <Brain className="w-6 h-6 text-blue-600" />
            <span className="text-xl font-bold gradient-text">Pyter</span>
          </div>
          <Button onClick={() => (window.location.href = getLoginUrl())} className="bg-blue-600 text-white hover:bg-blue-700 px-6 py-3 rounded-lg font-medium transition-all">
            Entrar
          </Button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="container py-20 md:py-32">
        <div className="max-w-3xl mx-auto text-center animate-fadeInUp">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">
            Explore Seus <span className="gradient-text">Padrões Cognitivos</span>
          </h1>
          <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
            Uma plataforma elegante para entender como você interage com Inteligência Artificial
            e descobrir seu perfil cognitivo único baseado no estudo Pyter.
          </p>
          <Button
            size="lg"
            className="bg-blue-600 text-white hover:bg-blue-700 px-6 py-3 rounded-lg font-medium transition-all"
            onClick={() => (window.location.href = getLoginUrl())}
          >
            Começar Agora
            <ArrowRight className="ml-2 w-4 h-4" />
          </Button>
        </div>
      </section>

      {/* Features Grid */}
      <section className="container py-20">
        <h2 className="text-3xl font-bold text-center mb-12">Funcionalidades Principais</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[
            {
              icon: MessageCircle,
              title: "Chat Inteligente",
              description: "Converse com uma IA que se adapta ao seu perfil cognitivo e ajusta seu tom de voz.",
            },
            {
              icon: Brain,
              title: "Classificação de Perfil",
              description: "Descubra se você é IA-Nativo, IA-Compatível ou Neurotípico através de análise em tempo real.",
            },
            {
              icon: BarChart3,
              title: "Métricas Detalhadas",
              description: "Visualize seu ECIA Estimado e análise de literalidade, contextualização e modularidade.",
            },
            {
              icon: Zap,
              title: "Protocolo de Autonomia",
              description: "Explore os 4 níveis de autonomia e como a IA se relaciona com você em cada estágio.",
            },
            {
              icon: Brain,
              title: "Base de Conhecimento",
              description: "Acesse dados completos do estudo Pyter sobre perfis cognitivos e interação com IA.",
            },
            {
              icon: BarChart3,
              title: "Dashboard Analítico",
              description: "Visualize gráficos comparativos de IAs, perfis e padrões de comportamento.",
            },
          ].map((feature, idx) => (
            <Card key={idx} className="rounded-xl border border-border shadow-sm p-6 group hover:border-blue-500/50">
              <feature.icon className="w-8 h-8 text-blue-600 mb-4 group-hover:scale-110 smooth-transition" />
              <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
              <p className="text-muted-foreground text-sm">{feature.description}</p>
            </Card>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="container py-20">
        <Card className="rounded-xl border border-border shadow-sm p-6 bg-gradient-to-r from-blue-600/10 to-purple-600/10 border-blue-500/20">
          <div className="text-center">
            <h2 className="text-3xl font-bold mb-4">Pronto para começar?</h2>
            <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
              Inicie uma conversa e deixe a IA analisar seus padrões cognitivos em tempo real.
            </p>
            <Button
              size="lg"
              className="bg-blue-600 text-white hover:bg-blue-700 px-6 py-3 rounded-lg font-medium transition-all"
              onClick={() => (window.location.href = getLoginUrl())}
            >
              Entrar Agora
              <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
          </div>
        </Card>
      </section>
    </div>
  );
}
